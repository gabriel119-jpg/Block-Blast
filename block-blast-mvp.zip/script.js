const gridSize = 9;
const grid = [];
const gridElement = document.getElementById('grid');
const piecesElement = document.getElementById('pieces');
const scoreElement = document.getElementById('score');
let score = 0;

function createGrid() {
  gridElement.innerHTML = '';
  for (let i = 0; i < gridSize * gridSize; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    grid.push(cell);
    gridElement.appendChild(cell);
  }
}

function getGridIndex(x, y) {
  return y * gridSize + x;
}

function generatePiece() {
  const shapes = [
    [[1, 1, 1]],
    [[1], [1], [1]],
    [[1, 1], [1, 0]]
  ];
  const shape = shapes[Math.floor(Math.random() * shapes.length)];
  return shape;
}

function renderPieces() {
  piecesElement.innerHTML = '';
  for (let i = 0; i < 3; i++) {
    const shape = generatePiece();
    const pieceDiv = document.createElement('div');
    pieceDiv.classList.add('piece');
    pieceDiv.style.gridTemplateColumns = `repeat(${shape[0].length}, 30px)`;
    shape.forEach(row => {
      row.forEach(cell => {
        const block = document.createElement('div');
        if (cell) block.classList.add('block');
        pieceDiv.appendChild(block);
      });
    });

    pieceDiv.addEventListener('click', () => placePiece(shape));
    piecesElement.appendChild(pieceDiv);
  }
}

function placePiece(shape) {
  for (let y = 0; y <= gridSize - shape.length; y++) {
    for (let x = 0; x <= gridSize - shape[0].length; x++) {
      if (canPlace(shape, x, y)) {
        applyPiece(shape, x, y);
        renderPieces();
        checkLines();
        return;
      }
    }
  }
  alert('No space to place this piece!');
}

function canPlace(shape, x, y) {
  for (let dy = 0; dy < shape.length; dy++) {
    for (let dx = 0; dx < shape[0].length; dx++) {
      if (shape[dy][dx]) {
        const index = getGridIndex(x + dx, y + dy);
        if (grid[index].classList.contains('filled')) return false;
      }
    }
  }
  return true;
}

function applyPiece(shape, x, y) {
  for (let dy = 0; dy < shape.length; dy++) {
    for (let dx = 0; dx < shape[0].length; dx++) {
      if (shape[dy][dx]) {
        const index = getGridIndex(x + dx, y + dy);
        grid[index].classList.add('filled');
      }
    }
  }
}

function checkLines() {
  let linesCleared = 0;

  for (let y = 0; y < gridSize; y++) {
    let full = true;
    for (let x = 0; x < gridSize; x++) {
      if (!grid[getGridIndex(x, y)].classList.contains('filled')) {
        full = false;
        break;
      }
    }
    if (full) {
      linesCleared++;
      for (let x = 0; x < gridSize; x++) {
        grid[getGridIndex(x, y)].classList.remove('filled');
      }
    }
  }

  for (let x = 0; x < gridSize; x++) {
    let full = true;
    for (let y = 0; y < gridSize; y++) {
      if (!grid[getGridIndex(x, y)].classList.contains('filled')) {
        full = false;
        break;
      }
    }
    if (full) {
      linesCleared++;
      for (let y = 0; y < gridSize; y++) {
        grid[getGridIndex(x, y)].classList.remove('filled');
      }
    }
  }

  score += linesCleared * 10;
  scoreElement.textContent = `Score: ${score}`;
}

createGrid();
renderPieces();